"""All web routes, forms and access-control rules for CareScope.

Sections: 1) helpers  2) forms  3) auth  4) dashboards  5) admin pages
          6) patients  7) appointments  8) encounters
"""
import re
from datetime import date, datetime, time
from functools import wraps
from urllib.parse import urlparse

from flask import (Blueprint, abort, current_app, flash, redirect, render_template,
                   request, url_for)
from flask_login import current_user, login_required, login_user, logout_user
from flask_wtf import FlaskForm
from sqlalchemy import func, or_
from sqlalchemy.exc import SQLAlchemyError
from wtforms import (DateField, FloatField, IntegerField, PasswordField, SelectField,
                     StringField, SubmitField, TextAreaField, TimeField)
from wtforms.validators import (DataRequired, Email, Length, NumberRange, Optional,
                                Regexp, ValidationError)

from .extensions import db, login_manager
from .models import (APPOINTMENT_STATUSES, BLOOD_GROUPS, GENDERS, Appointment, AuditLog,
                     Department, Encounter, Patient, User)
from .services.audit import log_action
from .services.risk import assess_risk

bp = Blueprint("main", __name__)

# ----------------------------------------------------------------------------
# 1) Helpers
# ----------------------------------------------------------------------------

PHONE_PATTERN = r"^\+?[0-9][0-9\s\-]{6,18}$"
USERNAME_PATTERN = r"^[A-Za-z0-9_.]{3,30}$"

# Which new status each current status may be changed to (staff only).
STATUS_TRANSITIONS = {
    "Scheduled": ["Confirmed", "Completed", "Cancelled", "No-Show"],
    "Confirmed": ["Completed", "Cancelled", "No-Show"],
}

DASHBOARD_ENDPOINTS = {
    "admin": "main.admin_dashboard",
    "doctor": "main.doctor_dashboard",
    "staff": "main.staff_dashboard",
}


def roles_required(*roles):
    """Server-side role check. Anonymous users go to login; wrong role gets 403."""
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                return login_manager.unauthorized()
            if current_user.role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapper
    return decorator


def safe_commit(error_message="The change could not be saved. Please try again."):
    """Commit the session. On failure: roll back, log the error and tell the user."""
    try:
        db.session.commit()
        return True
    except SQLAlchemyError:
        db.session.rollback()
        current_app.logger.exception("Database commit failed")
        flash(error_message, "danger")
        return False


def is_safe_redirect(target):
    """Only allow redirects to paths inside this site."""
    if not target:
        return False
    parsed = urlparse(target)
    return parsed.scheme == "" and parsed.netloc == "" and target.startswith("/")


def clean(value):
    """Strip text; empty text becomes None."""
    if value is None:
        return None
    value = value.strip()
    return value or None


def status_counts(query_rows, all_labels):
    """Turn [(label, count), ...] into a dict that includes zero counts."""
    counts = {label: 0 for label in all_labels}
    for label, count in query_rows:
        counts[label] = count
    return counts


def risk_counts(doctor_id=None):
    """Count Low/Moderate/High using each active patient's most recent encounter."""
    latest_ids = db.select(func.max(Encounter.id)).group_by(Encounter.patient_id)
    query = (db.session.query(Encounter.risk_level, func.count(Encounter.id))
             .join(Patient, Patient.id == Encounter.patient_id)
             .filter(Encounter.id.in_(latest_ids), Patient.status == "Active"))
    if doctor_id is not None:
        query = query.filter(Patient.assigned_doctor_id == doctor_id)
    rows = query.group_by(Encounter.risk_level).all()
    return status_counts(rows, ["Low", "Moderate", "High"])


def appointment_status_counts(doctor_id=None):
    query = db.session.query(Appointment.status, func.count(Appointment.id))
    if doctor_id is not None:
        query = query.filter(Appointment.doctor_id == doctor_id)
    return status_counts(query.group_by(Appointment.status).all(), APPOINTMENT_STATUSES)


def department_choices(required=True):
    choices = [] if required else [(0, "-- No department --")]
    departments = Department.query.order_by(Department.name).all()
    choices += [(d.id, d.name + ("" if d.is_active else " (inactive)")) for d in departments]
    return choices


def doctor_choices(include_id=None, allow_none=False):
    """Active doctors (plus one specific doctor, e.g. the patient's current doctor)."""
    query = User.query.filter(User.role == "doctor")
    if include_id:
        query = query.filter(or_(User.is_active.is_(True), User.id == include_id))
    else:
        query = query.filter(User.is_active.is_(True))
    choices = [(0, "-- Unassigned --")] if allow_none else []
    choices += [(d.id, d.full_name + ("" if d.is_active else " (inactive)"))
                for d in query.order_by(User.full_name).all()]
    return choices


def get_patient_for_current_user(patient_id):
    """Fetch a patient or 404; doctors may only open their own assigned patients."""
    patient = db.get_or_404(Patient, patient_id)
    if current_user.role == "doctor" and patient.assigned_doctor_id != current_user.id:
        abort(403)
    return patient


# ----------------------------------------------------------------------------
# 2) Forms
# ----------------------------------------------------------------------------

def strong_password(form, field):
    value = field.data or ""
    if len(value) < 8 or not re.search(r"[A-Za-z]", value) or not re.search(r"\d", value):
        raise ValidationError("Password must be at least 8 characters and contain letters and numbers.")


class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(max=50)])
    password = PasswordField("Password", validators=[DataRequired(), Length(max=128)])
    submit = SubmitField("Sign in")


class UserBaseForm(FlaskForm):
    """Fields shared by the doctor and staff forms."""
    full_name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=120)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    username = StringField("Username", validators=[
        DataRequired(),
        Regexp(USERNAME_PATTERN, message="3-30 characters: letters, numbers, dot or underscore only."),
    ])
    password = PasswordField("Password", validators=[Length(max=128)])
    phone = StringField("Phone", validators=[
        DataRequired(), Regexp(PHONE_PATTERN, message="Enter a valid phone number (7-15 digits).")])
    department_id = SelectField("Department", coerce=int)
    submit = SubmitField("Save")

    def __init__(self, *args, user_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_id = user_id  # None when adding a new user
        self.department_id.choices = department_choices(required=False)

    def validate_password(self, field):
        if not field.data:
            if self.user_id is None:
                raise ValidationError("Password is required for a new account.")
            return  # editing: blank means "keep the current password"
        strong_password(self, field)

    def validate_username(self, field):
        existing = User.query.filter(func.lower(User.username) == field.data.strip().lower()).first()
        if existing and existing.id != self.user_id:
            raise ValidationError("That username is already taken.")

    def validate_email(self, field):
        existing = User.query.filter(func.lower(User.email) == field.data.strip().lower()).first()
        if existing and existing.id != self.user_id:
            raise ValidationError("That email is already registered.")


class DoctorForm(UserBaseForm):
    specialization = StringField("Specialization", validators=[DataRequired(), Length(max=100)])

    def validate_department_id(self, field):
        if field.data == 0:
            raise ValidationError("Please choose a department for the doctor.")


class StaffForm(UserBaseForm):
    designation = StringField("Designation", validators=[DataRequired(), Length(max=100)])


class DepartmentForm(FlaskForm):
    name = StringField("Department name", validators=[DataRequired(), Length(min=2, max=100)])
    description = StringField("Description", validators=[Optional(), Length(max=255)])
    submit = SubmitField("Save")

    def __init__(self, *args, department_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.department_id = department_id

    def validate_name(self, field):
        existing = Department.query.filter(func.lower(Department.name) == field.data.strip().lower()).first()
        if existing and existing.id != self.department_id:
            raise ValidationError("A department with that name already exists.")


class PatientForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=120)])
    date_of_birth = DateField("Date of birth", validators=[DataRequired(message="Enter a valid date.")])
    gender = SelectField("Gender", choices=[(g, g) for g in GENDERS])
    phone = StringField("Phone", validators=[
        DataRequired(), Regexp(PHONE_PATTERN, message="Enter a valid phone number (7-15 digits).")])
    email = StringField("Email", validators=[Optional(), Email(), Length(max=120)])
    address = TextAreaField("Address", validators=[Optional(), Length(max=255)])
    blood_group = SelectField("Blood group", choices=[("", "Unknown")] + [(b, b) for b in BLOOD_GROUPS])
    assigned_doctor_id = SelectField("Assigned doctor", coerce=int)
    submit = SubmitField("Save patient")

    def __init__(self, *args, current_doctor_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.assigned_doctor_id.choices = doctor_choices(include_id=current_doctor_id, allow_none=True)

    def validate_date_of_birth(self, field):
        today = date.today()
        if field.data > today:
            raise ValidationError("Date of birth cannot be in the future.")
        if field.data.year < today.year - 130:
            raise ValidationError("Please enter a realistic date of birth.")


class AppointmentForm(FlaskForm):
    patient_id = SelectField("Patient", coerce=int)
    doctor_id = SelectField("Doctor", coerce=int)
    appointment_date = DateField("Date", validators=[DataRequired(message="Enter a valid date.")])
    appointment_time = TimeField("Time", validators=[DataRequired(message="Enter a valid time.")])
    reason = StringField("Reason for visit", validators=[DataRequired(), Length(min=3, max=255)])
    submit = SubmitField("Book appointment")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        patients = Patient.query.filter_by(status="Active").order_by(Patient.full_name).all()
        self.patient_id.choices = [(p.id, f"{p.full_name} ({p.patient_code})") for p in patients]
        self.doctor_id.choices = doctor_choices()

    def validate_appointment_date(self, field):
        if field.data < date.today():
            raise ValidationError("Appointment date cannot be in the past.")

    def validate_appointment_time(self, field):
        if field.data < time(8, 0) or field.data > time(18, 0):
            raise ValidationError("Appointments can be booked between 08:00 and 18:00.")
        if self.appointment_date.data == date.today() and field.data <= datetime.now().time():
            raise ValidationError("That time has already passed today.")


class EncounterForm(FlaskForm):
    patient_id = SelectField("Patient", coerce=int)
    encounter_date = DateField("Encounter date", validators=[DataRequired(message="Enter a valid date.")])
    symptoms = TextAreaField("Symptoms", validators=[DataRequired(), Length(max=2000)])
    diagnosis = TextAreaField("Diagnosis", validators=[Optional(), Length(max=2000)])
    systolic_bp = IntegerField("Systolic BP (mmHg)", validators=[Optional(), NumberRange(50, 300)])
    diastolic_bp = IntegerField("Diastolic BP (mmHg)", validators=[Optional(), NumberRange(30, 200)])
    heart_rate = IntegerField("Heart rate (bpm)", validators=[Optional(), NumberRange(20, 250)])
    temperature = FloatField("Temperature (\u00b0C)", validators=[Optional(), NumberRange(30, 45)])
    oxygen_saturation = IntegerField("Oxygen saturation (%)", validators=[Optional(), NumberRange(50, 100)])
    bmi = FloatField("BMI", validators=[Optional(), NumberRange(8, 80)])
    glucose = FloatField("Glucose (mg/dL)", validators=[Optional(), NumberRange(20, 800)])
    treatment_notes = TextAreaField("Treatment notes", validators=[Optional(), Length(max=2000)])
    follow_up_date = DateField("Follow-up date", validators=[Optional()])
    submit = SubmitField("Save encounter")

    def validate_encounter_date(self, field):
        if field.data > date.today():
            raise ValidationError("Encounter date cannot be in the future.")

    def validate_systolic_bp(self, field):
        if self.diastolic_bp.data is None:
            raise ValidationError("Enter the diastolic value as well.")
        if self.diastolic_bp.data >= field.data:
            raise ValidationError("Systolic must be higher than diastolic.")

    def validate_diastolic_bp(self, field):
        if self.systolic_bp.data is None:
            raise ValidationError("Enter the systolic value as well.")

    def validate_follow_up_date(self, field):
        if self.encounter_date.data and field.data < self.encounter_date.data:
            raise ValidationError("Follow-up date cannot be before the encounter date.")


# ----------------------------------------------------------------------------
# 3) Authentication
# ----------------------------------------------------------------------------

@bp.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for(DASHBOARD_ENDPOINTS[current_user.role]))
    return redirect(url_for("main.login"))


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for(DASHBOARD_ENDPOINTS[current_user.role]))
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data.strip().lower()
        user = User.query.filter(User.username == username).first()
        if user is not None and user.check_password(form.password.data):
            if not user.is_active:
                flash("This account has been deactivated. Please contact the administrator.", "danger")
            else:
                login_user(user)
                log_action("login", f"User {user.username} signed in", user_id=user.id)
                safe_commit()
                next_url = request.args.get("next")
                if is_safe_redirect(next_url):
                    return redirect(next_url)
                return redirect(url_for(DASHBOARD_ENDPOINTS[user.role]))
        else:
            log_action("login_failed", f"Failed sign-in for username '{username[:50]}'")
            safe_commit()
            flash("Invalid username or password.", "danger")
    return render_template("auth/login.html", form=form)


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    log_action("logout", f"User {current_user.username} signed out")
    safe_commit()
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("main.login"))


# ----------------------------------------------------------------------------
# 4) Dashboards
# ----------------------------------------------------------------------------

@bp.route("/admin/dashboard")
@roles_required("admin")
def admin_dashboard():
    stats = {
        "patients": Patient.query.count(),
        "doctors": User.query.filter_by(role="doctor", is_active=True).count(),
        "staff": User.query.filter_by(role="staff", is_active=True).count(),
        "appointments": Appointment.query.count(),
        "encounters": Encounter.query.count(),
    }
    todays = (Appointment.query.filter_by(appointment_date=date.today())
              .order_by(Appointment.appointment_time).all())
    return render_template("admin/dashboard.html", stats=stats, risk=risk_counts(),
                           appt_status=appointment_status_counts(), todays=todays)


@bp.route("/doctor/dashboard")
@roles_required("doctor")
def doctor_dashboard():
    stats = {
        "patients": Patient.query.filter_by(assigned_doctor_id=current_user.id, status="Active").count(),
        "appointments": Appointment.query.filter_by(doctor_id=current_user.id).count(),
        "encounters": Encounter.query.filter_by(doctor_id=current_user.id).count(),
    }
    todays = (Appointment.query.filter_by(doctor_id=current_user.id, appointment_date=date.today())
              .order_by(Appointment.appointment_time).all())
    latest_ids = db.select(func.max(Encounter.id)).group_by(Encounter.patient_id)
    high_risk = (Encounter.query.join(Patient, Patient.id == Encounter.patient_id)
                 .filter(Encounter.id.in_(latest_ids), Encounter.risk_level == "High",
                         Patient.assigned_doctor_id == current_user.id, Patient.status == "Active")
                 .order_by(Encounter.encounter_date.desc()).limit(10).all())
    return render_template("doctor/dashboard.html", stats=stats,
                           risk=risk_counts(current_user.id),
                           appt_status=appointment_status_counts(current_user.id),
                           todays=todays, high_risk=high_risk)


@bp.route("/staff/dashboard")
@roles_required("staff")
def staff_dashboard():
    stats = {
        "patients": Patient.query.filter_by(status="Active").count(),
        "doctors": User.query.filter_by(role="doctor", is_active=True).count(),
        "appointments": Appointment.query.count(),
        "today": Appointment.query.filter_by(appointment_date=date.today()).count(),
    }
    gender_rows = (db.session.query(Patient.gender, func.count(Patient.id))
                   .group_by(Patient.gender).all())
    todays = (Appointment.query.filter_by(appointment_date=date.today())
              .order_by(Appointment.appointment_time).all())
    return render_template("staff/dashboard.html", stats=stats,
                           appt_status=appointment_status_counts(),
                           gender=status_counts(gender_rows, GENDERS), todays=todays)


# ----------------------------------------------------------------------------
# 5) Admin pages: doctors, staff, departments, patients, reports
# ----------------------------------------------------------------------------

def get_user_or_404(user_id, role):
    user = db.get_or_404(User, user_id)
    if user.role != role:
        abort(404)
    return user


def manage_users(role, form_class, template, list_endpoint, edit_user=None):
    """Shared list + add + edit logic for doctors and staff."""
    search = request.args.get("q", "").strip()
    query = User.query.filter_by(role=role)
    if search:
        like = f"%{search}%"
        query = query.filter(or_(User.full_name.ilike(like), User.username.ilike(like),
                                 User.email.ilike(like)))
    users = query.order_by(User.full_name).all()

    form = form_class(obj=edit_user, user_id=edit_user.id if edit_user else None)
    if form.validate_on_submit():
        user = edit_user or User(role=role, is_active=True)
        user.full_name = form.full_name.data.strip()
        user.email = form.email.data.strip().lower()
        user.username = form.username.data.strip().lower()
        user.phone = form.phone.data.strip()
        user.department_id = form.department_id.data or None
        if role == "doctor":
            user.specialization = form.specialization.data.strip()
        else:
            user.designation = form.designation.data.strip()
        if form.password.data:
            user.set_password(form.password.data)
        if edit_user is None:
            db.session.add(user)
        log_action(f"{role}_{'updated' if edit_user else 'created'}", f"{role} username {user.username}")
        if safe_commit():
            flash(f"{role.capitalize()} {'updated' if edit_user else 'added'} successfully.", "success")
            return redirect(url_for(list_endpoint))
    return render_template(template, users=users, form=form, editing=edit_user, search=search)


def toggle_user(user, list_endpoint):
    user.is_active = not user.is_active
    action = "activated" if user.is_active else "deactivated"
    log_action(f"{user.role}_{action}", f"{user.role} username {user.username}")
    if safe_commit():
        flash(f"{user.full_name} has been {action}.", "success")
    return redirect(url_for(list_endpoint))


@bp.route("/admin/doctors", methods=["GET", "POST"])
@roles_required("admin")
def admin_doctors():
    return manage_users("doctor", DoctorForm, "admin/doctors.html", "main.admin_doctors")


@bp.route("/admin/doctors/<int:user_id>/edit", methods=["GET", "POST"])
@roles_required("admin")
def admin_doctor_edit(user_id):
    doctor = get_user_or_404(user_id, "doctor")
    return manage_users("doctor", DoctorForm, "admin/doctors.html", "main.admin_doctors", edit_user=doctor)


@bp.route("/admin/doctors/<int:user_id>/toggle", methods=["POST"])
@roles_required("admin")
def admin_doctor_toggle(user_id):
    return toggle_user(get_user_or_404(user_id, "doctor"), "main.admin_doctors")


@bp.route("/admin/staff", methods=["GET", "POST"])
@roles_required("admin")
def admin_staff():
    return manage_users("staff", StaffForm, "admin/staff.html", "main.admin_staff")


@bp.route("/admin/staff/<int:user_id>/edit", methods=["GET", "POST"])
@roles_required("admin")
def admin_staff_edit(user_id):
    member = get_user_or_404(user_id, "staff")
    return manage_users("staff", StaffForm, "admin/staff.html", "main.admin_staff", edit_user=member)


@bp.route("/admin/staff/<int:user_id>/toggle", methods=["POST"])
@roles_required("admin")
def admin_staff_toggle(user_id):
    return toggle_user(get_user_or_404(user_id, "staff"), "main.admin_staff")


def manage_departments(edit_department=None):
    form = DepartmentForm(obj=edit_department,
                          department_id=edit_department.id if edit_department else None)
    if form.validate_on_submit():
        department = edit_department or Department(is_active=True)
        department.name = form.name.data.strip()
        department.description = clean(form.description.data)
        if edit_department is None:
            db.session.add(department)
        log_action("department_updated" if edit_department else "department_created", department.name)
        if safe_commit():
            flash("Department saved.", "success")
            return redirect(url_for("main.admin_departments"))
    departments = Department.query.order_by(Department.name).all()
    member_counts = dict(db.session.query(User.department_id, func.count(User.id))
                         .filter(User.is_active.is_(True), User.department_id.isnot(None))
                         .group_by(User.department_id).all())
    return render_template("admin/departments.html", departments=departments, form=form,
                           editing=edit_department, member_counts=member_counts)


@bp.route("/admin/departments", methods=["GET", "POST"])
@roles_required("admin")
def admin_departments():
    return manage_departments()


@bp.route("/admin/departments/<int:department_id>/edit", methods=["GET", "POST"])
@roles_required("admin")
def admin_department_edit(department_id):
    return manage_departments(db.get_or_404(Department, department_id))


@bp.route("/admin/departments/<int:department_id>/toggle", methods=["POST"])
@roles_required("admin")
def admin_department_toggle(department_id):
    department = db.get_or_404(Department, department_id)
    if department.is_active:
        in_use = User.query.filter_by(department_id=department.id, is_active=True).count()
        if in_use:
            flash("This department still has active doctors or staff. Move or deactivate them first.", "warning")
            return redirect(url_for("main.admin_departments"))
    department.is_active = not department.is_active
    log_action("department_toggled", f"{department.name} active={department.is_active}")
    if safe_commit():
        flash(f"Department {'activated' if department.is_active else 'deactivated'}.", "success")
    return redirect(url_for("main.admin_departments"))


@bp.route("/admin/patients")
@roles_required("admin")
def admin_patients():
    patients, search, status = search_patients()
    return render_template("admin/patients.html", patients=patients, search=search, status=status)


@bp.route("/admin/reports")
@roles_required("admin")
def admin_reports():
    gender_rows = db.session.query(Patient.gender, func.count(Patient.id)).group_by(Patient.gender).all()
    blood_rows = db.session.query(Patient.blood_group, func.count(Patient.id)).group_by(Patient.blood_group).all()
    blood = {}
    for group, count in blood_rows:
        blood[group or "Unknown"] = blood.get(group or "Unknown", 0) + count
    per_doctor = (db.session.query(User.full_name, func.count(Appointment.id))
                  .join(Appointment, Appointment.doctor_id == User.id)
                  .group_by(User.id, User.full_name).order_by(func.count(Appointment.id).desc()).all())
    recent_activity = AuditLog.query.order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(15).all()
    return render_template("admin/reports.html",
                           gender=status_counts(gender_rows, GENDERS), blood=blood,
                           per_doctor=per_doctor, appt_status=appointment_status_counts(),
                           risk=risk_counts(), recent_activity=recent_activity)


# ----------------------------------------------------------------------------
# 6) Patients
# ----------------------------------------------------------------------------

def search_patients():
    """Search/filter patients. Doctors only ever see their own assigned patients."""
    search = request.args.get("q", "").strip()
    status = request.args.get("status", "Active")
    query = Patient.query
    if current_user.role == "doctor":
        query = query.filter(Patient.assigned_doctor_id == current_user.id)
    if status in ("Active", "Inactive"):
        query = query.filter(Patient.status == status)
    else:
        status = "all"
    if search:
        like = f"%{search}%"
        query = query.filter(or_(Patient.full_name.ilike(like), Patient.patient_code.ilike(like),
                                 Patient.phone.ilike(like)))
    return query.order_by(Patient.registered_at.desc(), Patient.id.desc()).limit(200).all(), search, status


def patient_list_url():
    if current_user.role == "admin":
        return url_for("main.admin_patients")
    return url_for("main.patients_list")


@bp.route("/patients")
@roles_required("doctor", "staff")
def patients_list():
    patients, search, status = search_patients()
    return render_template("patients/list.html", patients=patients, search=search, status=status)


def fill_patient(patient, form):
    patient.full_name = form.full_name.data.strip()
    patient.date_of_birth = form.date_of_birth.data
    patient.gender = form.gender.data
    patient.phone = form.phone.data.strip()
    patient.email = clean(form.email.data)
    patient.address = clean(form.address.data)
    patient.blood_group = form.blood_group.data or None
    patient.assigned_doctor_id = form.assigned_doctor_id.data or None


@bp.route("/patients/new", methods=["GET", "POST"])
@roles_required("admin", "staff")
def patient_new():
    form = PatientForm()
    if form.validate_on_submit():
        patient = Patient(patient_code=f"TMP{datetime.now().strftime('%y%m%d%H%M%S%f')}"[:20],
                          status="Active", created_by=current_user.id)
        fill_patient(patient, form)
        try:
            db.session.add(patient)
            db.session.flush()  # gives the new row its id
            patient.patient_code = f"CS{patient.id:05d}"
            log_action("patient_registered", f"{patient.patient_code} {patient.full_name}")
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            current_app.logger.exception("Patient registration failed")
            flash("The patient could not be saved. Please try again.", "danger")
        else:
            flash(f"Patient registered with code {patient.patient_code}.", "success")
            return redirect(url_for("main.patient_detail", patient_id=patient.id))
    return render_template("patients/form.html", form=form, editing=None)


@bp.route("/patients/<int:patient_id>")
@roles_required("admin", "doctor", "staff")
def patient_detail(patient_id):
    patient = get_patient_for_current_user(patient_id)
    appointments = sorted(patient.appointments,
                          key=lambda a: (a.appointment_date, a.appointment_time), reverse=True)
    return render_template("patients/detail.html", patient=patient, appointments=appointments)


@bp.route("/patients/<int:patient_id>/edit", methods=["GET", "POST"])
@roles_required("admin", "staff")
def patient_edit(patient_id):
    patient = db.get_or_404(Patient, patient_id)
    form = PatientForm(obj=patient, current_doctor_id=patient.assigned_doctor_id)
    if form.validate_on_submit():
        fill_patient(patient, form)
        log_action("patient_updated", f"{patient.patient_code} {patient.full_name}")
        if safe_commit():
            flash("Patient details updated.", "success")
            return redirect(url_for("main.patient_detail", patient_id=patient.id))
    return render_template("patients/form.html", form=form, editing=patient)


@bp.route("/patients/<int:patient_id>/status", methods=["POST"])
@roles_required("admin")
def patient_toggle_status(patient_id):
    patient = db.get_or_404(Patient, patient_id)
    patient.status = "Inactive" if patient.status == "Active" else "Active"
    log_action("patient_status_changed", f"{patient.patient_code} now {patient.status}")
    if safe_commit():
        flash(f"{patient.full_name} is now {patient.status}.", "success")
    next_url = request.form.get("next")
    if is_safe_redirect(next_url):
        return redirect(next_url)
    return redirect(url_for("main.admin_patients"))


# ----------------------------------------------------------------------------
# 7) Appointments
# ----------------------------------------------------------------------------

@bp.route("/appointments")
@roles_required("admin", "doctor", "staff")
def appointments_list():
    status = request.args.get("status", "")
    date_text = request.args.get("date", "").strip()
    query = Appointment.query
    if current_user.role == "doctor":
        query = query.filter(Appointment.doctor_id == current_user.id)
    if status in APPOINTMENT_STATUSES:
        query = query.filter(Appointment.status == status)
    else:
        status = ""
    chosen_date = None
    if date_text:
        try:
            chosen_date = datetime.strptime(date_text, "%Y-%m-%d").date()
            query = query.filter(Appointment.appointment_date == chosen_date)
        except ValueError:
            flash("The date filter was not valid and was ignored.", "warning")
            date_text = ""
    appointments = (query.order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc())
                    .limit(300).all())
    return render_template("appointments/list.html", appointments=appointments, status=status,
                           date_text=date_text, statuses=APPOINTMENT_STATUSES,
                           transitions=STATUS_TRANSITIONS)


def find_booking_conflict(form):
    """Return an error message if this booking would be an obvious duplicate, else None."""
    same_day = Appointment.query.filter(
        Appointment.appointment_date == form.appointment_date.data,
        Appointment.status != "Cancelled",
    )
    if same_day.filter(Appointment.doctor_id == form.doctor_id.data,
                       Appointment.appointment_time == form.appointment_time.data).first():
        return "This doctor already has an appointment at that date and time."
    if same_day.filter(Appointment.patient_id == form.patient_id.data,
                       Appointment.appointment_time == form.appointment_time.data).first():
        return "This patient already has another appointment at that date and time."
    if same_day.filter(Appointment.patient_id == form.patient_id.data,
                       Appointment.doctor_id == form.doctor_id.data).first():
        return "This patient already has an appointment with this doctor on that day."
    return None


@bp.route("/appointments/new", methods=["GET", "POST"])
@roles_required("staff")
def appointment_new():
    form = AppointmentForm()
    if request.method == "GET":
        preselected = request.args.get("patient_id", type=int)
        if preselected and preselected in [value for value, _ in form.patient_id.choices]:
            form.patient_id.data = preselected
    if form.validate_on_submit():
        conflict = find_booking_conflict(form)
        if conflict:
            flash(conflict, "danger")
        else:
            appointment = Appointment(
                patient_id=form.patient_id.data, doctor_id=form.doctor_id.data,
                appointment_date=form.appointment_date.data,
                appointment_time=form.appointment_time.data,
                reason=form.reason.data.strip(), status="Scheduled", created_by=current_user.id)
            db.session.add(appointment)
            log_action("appointment_booked", f"patient {form.patient_id.data} on {form.appointment_date.data}")
            if safe_commit():
                flash("Appointment booked.", "success")
                return redirect(url_for("main.appointments_list"))
    return render_template("appointments/form.html", form=form)


@bp.route("/appointments/<int:appointment_id>/status", methods=["POST"])
@roles_required("staff")
def appointment_update_status(appointment_id):
    appointment = db.get_or_404(Appointment, appointment_id)
    new_status = request.form.get("status", "")
    allowed = STATUS_TRANSITIONS.get(appointment.status, [])
    if new_status not in allowed:
        flash("That status change is not allowed for this appointment.", "danger")
    else:
        old_status = appointment.status
        appointment.status = new_status
        log_action("appointment_status", f"appointment {appointment.id}: {old_status} -> {new_status}")
        if safe_commit():
            flash(f"Appointment marked as {new_status}.", "success")
    return redirect(url_for("main.appointments_list"))


# ----------------------------------------------------------------------------
# 8) Encounters (doctors only)
# ----------------------------------------------------------------------------

def apply_encounter(encounter, form):
    """Copy form values onto the encounter and recalculate the risk indicator."""
    encounter.encounter_date = form.encounter_date.data
    encounter.symptoms = form.symptoms.data.strip()
    encounter.diagnosis = clean(form.diagnosis.data)
    encounter.systolic_bp = form.systolic_bp.data
    encounter.diastolic_bp = form.diastolic_bp.data
    encounter.heart_rate = form.heart_rate.data
    encounter.temperature = form.temperature.data
    encounter.oxygen_saturation = form.oxygen_saturation.data
    encounter.bmi = form.bmi.data
    encounter.glucose = form.glucose.data
    encounter.treatment_notes = clean(form.treatment_notes.data)
    encounter.follow_up_date = form.follow_up_date.data
    risk = assess_risk(
        systolic=encounter.systolic_bp, diastolic=encounter.diastolic_bp,
        heart_rate=encounter.heart_rate, temperature=encounter.temperature,
        oxygen=encounter.oxygen_saturation, bmi=encounter.bmi, glucose=encounter.glucose)
    encounter.risk_level = risk["level"]
    encounter.risk_reason = risk["reason"]


@bp.route("/encounters")
@roles_required("doctor")
def encounters_list():
    patient_id = request.args.get("patient_id", type=int)
    query = (Encounter.query.join(Patient, Patient.id == Encounter.patient_id)
             .filter(Patient.assigned_doctor_id == current_user.id))
    patient = None
    if patient_id:
        patient = get_patient_for_current_user(patient_id)
        query = query.filter(Encounter.patient_id == patient.id)
    encounters = query.order_by(Encounter.encounter_date.desc(), Encounter.id.desc()).limit(300).all()
    return render_template("encounters/list.html", encounters=encounters, patient=patient)


@bp.route("/encounters/new", methods=["GET", "POST"])
@roles_required("doctor")
def encounter_new():
    form = EncounterForm()
    my_patients = (Patient.query.filter_by(assigned_doctor_id=current_user.id, status="Active")
                   .order_by(Patient.full_name).all())
    form.patient_id.choices = [(p.id, f"{p.full_name} ({p.patient_code})") for p in my_patients]
    if request.method == "GET":
        form.encounter_date.data = date.today()
        preselected = request.args.get("patient_id", type=int)
        if preselected in [p.id for p in my_patients]:
            form.patient_id.data = preselected
    if form.validate_on_submit():
        encounter = Encounter(patient_id=form.patient_id.data, doctor_id=current_user.id)
        apply_encounter(encounter, form)
        db.session.add(encounter)
        log_action("encounter_created", f"patient {form.patient_id.data} risk {encounter.risk_level}")
        if safe_commit():
            flash(f"Encounter saved. Risk indicator: {encounter.risk_level}.", "success")
            return redirect(url_for("main.patient_detail", patient_id=encounter.patient_id))
    return render_template("encounters/form.html", form=form, editing=None, patient=None)


@bp.route("/encounters/<int:encounter_id>/edit", methods=["GET", "POST"])
@roles_required("doctor")
def encounter_edit(encounter_id):
    encounter = db.get_or_404(Encounter, encounter_id)
    if encounter.doctor_id != current_user.id:
        abort(403)
    form = EncounterForm(obj=encounter)
    del form.patient_id  # the patient of an existing encounter cannot be changed
    if form.validate_on_submit():
        apply_encounter(encounter, form)
        log_action("encounter_updated", f"encounter {encounter.id} risk {encounter.risk_level}")
        if safe_commit():
            flash(f"Encounter updated. Risk indicator: {encounter.risk_level}.", "success")
            return redirect(url_for("main.patient_detail", patient_id=encounter.patient_id))
    return render_template("encounters/form.html", form=form, editing=encounter,
                           patient=encounter.patient)
