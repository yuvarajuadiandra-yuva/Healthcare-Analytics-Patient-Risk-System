"""CareScope application factory."""
import click
from flask import Flask, render_template
from flask_wtf.csrf import CSRFError
from sqlalchemy.exc import SQLAlchemyError

from config import Config

from .extensions import csrf, db, login_manager
from .models import User
from .services.risk import DISCLAIMER


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    if not app.config.get("SECRET_KEY"):
        raise RuntimeError(
            "SECRET_KEY is not set. Copy .env.example to .env and set SECRET_KEY "
            "(see the README for the command that generates one)."
        )

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    from .routes import bp
    app.register_blueprint(bp)

    register_template_helpers(app)
    register_error_handlers(app)
    register_cli_commands(app)
    return app


def register_template_helpers(app):
    app.jinja_env.globals["risk_disclaimer"] = DISCLAIMER

    @app.template_filter("status_badge")
    def status_badge(status):
        colours = {
            "Active": "success", "Inactive": "secondary",
            "Scheduled": "primary", "Confirmed": "info", "Completed": "success",
            "Cancelled": "danger", "No-Show": "warning",
        }
        return colours.get(status, "secondary")

    @app.template_filter("risk_badge")
    def risk_badge(level):
        colours = {"Low": "success", "Moderate": "warning", "High": "danger"}
        return colours.get(level, "secondary")


def register_error_handlers(app):
    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/404.html"), 404

    @app.errorhandler(CSRFError)
    def csrf_failed(error):
        message = ("Your form session expired or was invalid. "
                   "Please go back, refresh the page and try again.")
        return render_template("errors/403.html", message=message), 400

    @app.errorhandler(500)
    def server_error(error):
        db.session.rollback()
        return render_template("errors/500.html"), 500


def register_cli_commands(app):
    @app.cli.command("init-db")
    def init_db_command():
        """Create any missing tables. Existing tables and data are never touched."""
        try:
            db.create_all()
        except SQLAlchemyError as error:
            raise click.ClickException(f"Could not connect to or write to the database: {error}")
        click.echo("Tables checked/created (existing tables were left unchanged).")

    @app.cli.command("create-admin")
    @click.option("--full-name", prompt="Full name")
    @click.option("--email", prompt="Email")
    @click.option("--username", prompt="Username")
    @click.password_option("--password", prompt="Password (min 8 chars, letters + numbers)")
    def create_admin_command(full_name, email, username, password):
        """Create an administrator account (used for the first login)."""
        username = username.strip().lower()
        email = email.strip().lower()
        if len(password) < 8 or password.isalpha() or password.isdigit():
            raise click.ClickException("Password must be at least 8 characters with letters and numbers.")
        if len(username) < 3:
            raise click.ClickException("Username must be at least 3 characters.")
        try:
            existing = User.query.filter(
                (User.username == username) | (User.email == email)
            ).first()
            if existing:
                raise click.ClickException("A user with that username or email already exists.")
            admin = User(full_name=full_name.strip(), email=email, username=username,
                         role="admin", is_active=True)
            admin.set_password(password)
            db.session.add(admin)
            db.session.commit()
        except SQLAlchemyError as error:
            db.session.rollback()
            raise click.ClickException(
                f"Database error (did you run database/schema.sql and set .env?): {error}"
            )
        click.echo(f"Administrator '{username}' created. You can now sign in.")
