"""Database models. Table and column names match database/schema.sql exactly."""
from datetime import date, datetime

from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db, login_manager

ROLES = ["admin", "doctor", "staff"]
GENDERS = ["Male", "Female", "Other"]
BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
PATIENT_STATUSES = ["Active", "Inactive"]
APPOINTMENT_STATUSES = ["Scheduled", "Confirmed", "Completed", "Cancelled", "No-Show"]


class Department(db.Model):
    __tablename__ = "departments"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)


class User(UserMixin, db.Model):
    """Admin, doctor and staff accounts share one table, separated by `role`."""
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    username = db.Column(db.String(50), nullable=False, unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    phone = db.Column(db.String(20))
    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"))
    specialization = db.Column(db.String(100))
    designation = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)

    department = db.relationship("Department", backref="users")

    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)


class Patient(db.Model):
    __tablename__ = "patients"

    id = db.Column(db.Integer, primary_key=True)
    patient_code = db.Column(db.String(20), nullable=False, unique=True)
    full_name = db.Column(db.String(120), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120))
    address = db.Column(db.String(255))
    blood_group = db.Column(db.String(5))
    assigned_doctor_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    registered_at = db.Column(db.DateTime, nullable=False, default=datetime.now)
    status = db.Column(db.String(10), nullable=False, default="Active")
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"))

    assigned_doctor = db.relationship("User", foreign_keys=[assigned_doctor_id])
    creator = db.relationship("User", foreign_keys=[created_by])
    encounters = db.relationship(
        "Encounter", backref="patient",
        order_by="[Encounter.encounter_date.desc(), Encounter.id.desc()]",
    )

    @property
    def age(self):
        """Age in years, calculated from the date of birth so it is never out of date."""
        today = date.today()
        dob = self.date_of_birth
        return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))

    @property
    def latest_encounter(self):
        return self.encounters[0] if self.encounters else None


class Appointment(db.Model):
    __tablename__ = "appointments"

    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patients.id"), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    appointment_time = db.Column(db.Time, nullable=False)
    reason = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Scheduled")
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)

    patient = db.relationship("Patient", backref="appointments")
    doctor = db.relationship("User", foreign_keys=[doctor_id])
    creator = db.relationship("User", foreign_keys=[created_by])


class Encounter(db.Model):
    __tablename__ = "encounters"

    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patients.id"), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    encounter_date = db.Column(db.Date, nullable=False)
    symptoms = db.Column(db.Text, nullable=False)
    diagnosis = db.Column(db.Text)
    systolic_bp = db.Column(db.Integer)
    diastolic_bp = db.Column(db.Integer)
    heart_rate = db.Column(db.Integer)
    temperature = db.Column(db.Numeric(4, 1, asdecimal=False))
    oxygen_saturation = db.Column(db.Integer)
    bmi = db.Column(db.Numeric(4, 1, asdecimal=False))
    glucose = db.Column(db.Numeric(5, 1, asdecimal=False))
    treatment_notes = db.Column(db.Text)
    follow_up_date = db.Column(db.Date)
    risk_level = db.Column(db.String(20), nullable=False, default="Not assessed")
    risk_reason = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    doctor = db.relationship("User", foreign_keys=[doctor_id])


class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    action = db.Column(db.String(60), nullable=False)
    details = db.Column(db.String(255))
    ip_address = db.Column(db.String(45))
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)

    user = db.relationship("User", foreign_keys=[user_id])


@login_manager.user_loader
def load_user(user_id):
    """Called by Flask-Login on every request. Deactivated users are logged out."""
    try:
        user = db.session.get(User, int(user_id))
    except (TypeError, ValueError):
        return None
    if user is not None and user.is_active:
        return user
    return None
