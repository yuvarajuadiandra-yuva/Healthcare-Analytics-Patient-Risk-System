"""Tiny audit logger: records who did what. The caller commits the session."""
from flask import request
from flask_login import current_user

from ..extensions import db
from ..models import AuditLog


def log_action(action, details=None, user_id=None):
    """Add an audit row to the current session (does not commit)."""
    if user_id is None and current_user.is_authenticated:
        user_id = current_user.id
    entry = AuditLog(
        user_id=user_id,
        action=action[:60],
        details=(details or "")[:255] or None,
        ip_address=(request.remote_addr or "")[:45] or None,
    )
    db.session.add(entry)
    return entry
