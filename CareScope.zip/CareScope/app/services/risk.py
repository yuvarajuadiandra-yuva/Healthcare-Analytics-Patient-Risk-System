"""Simple, transparent rule-based risk indicator.

EDUCATIONAL DEMONSTRATION ONLY. These thresholds are simplified examples chosen for a
student project. They are NOT clinically validated and must never be used for diagnosis
or treatment decisions.

How it works: every recorded measurement earns 0-3 points.
    0 = within the simple reference range used here
    1 = slightly outside, 2 = clearly outside, 3 = far outside
Final category:
    High     -> any single measurement scores 3, or the total is 5 or more
    Moderate -> any single measurement scores 2, or the total is 2 or more
    Low      -> everything else
"""

DISCLAIMER = (
    "Educational demonstration only. This rule-based indicator is not a medical diagnosis, "
    "is not a clinical decision tool, and has not been clinically validated."
)

RISK_LEVELS = ["Low", "Moderate", "High"]
NOT_ASSESSED = "Not assessed"


def _score_blood_pressure(systolic, diastolic):
    findings = []
    if systolic is not None:
        if systolic >= 180:
            findings.append((3, f"Systolic BP {systolic} mmHg is very high (180 or more)"))
        elif systolic >= 140:
            findings.append((2, f"Systolic BP {systolic} mmHg is high (140-179)"))
        elif systolic >= 130:
            findings.append((1, f"Systolic BP {systolic} mmHg is slightly raised (130-139)"))
        elif systolic < 90:
            findings.append((2, f"Systolic BP {systolic} mmHg is low (below 90)"))
    if diastolic is not None:
        if diastolic >= 120:
            findings.append((3, f"Diastolic BP {diastolic} mmHg is very high (120 or more)"))
        elif diastolic >= 90:
            findings.append((2, f"Diastolic BP {diastolic} mmHg is high (90-119)"))
        elif diastolic >= 80:
            findings.append((1, f"Diastolic BP {diastolic} mmHg is slightly raised (80-89)"))
        elif diastolic < 60:
            findings.append((1, f"Diastolic BP {diastolic} mmHg is low (below 60)"))
    return findings


def _score_heart_rate(heart_rate):
    if heart_rate is None:
        return []
    if heart_rate < 40 or heart_rate > 130:
        return [(3, f"Heart rate {heart_rate} bpm is far outside 60-100")]
    if heart_rate < 50 or heart_rate > 110:
        return [(2, f"Heart rate {heart_rate} bpm is clearly outside 60-100")]
    if heart_rate < 60 or heart_rate > 100:
        return [(1, f"Heart rate {heart_rate} bpm is slightly outside 60-100")]
    return []


def _score_temperature(temperature):
    if temperature is None:
        return []
    if temperature >= 39.5 or temperature < 35.0:
        return [(3, f"Temperature {temperature:g} C is far outside the normal range")]
    if temperature >= 38.0:
        return [(2, f"Temperature {temperature:g} C indicates fever (38.0 or more)")]
    if temperature >= 37.5:
        return [(1, f"Temperature {temperature:g} C is slightly raised (37.5-37.9)")]
    return []


def _score_oxygen(oxygen):
    if oxygen is None:
        return []
    if oxygen < 90:
        return [(3, f"Oxygen saturation {oxygen}% is very low (below 90)")]
    if oxygen < 94:
        return [(2, f"Oxygen saturation {oxygen}% is low (90-93)")]
    if oxygen < 96:
        return [(1, f"Oxygen saturation {oxygen}% is slightly low (94-95)")]
    return []


def _score_bmi(bmi):
    if bmi is None:
        return []
    if bmi >= 40 or bmi < 16:
        return [(2, f"BMI {bmi:g} is far outside 18.5-24.9")]
    if bmi >= 30 or bmi < 18.5:
        return [(1, f"BMI {bmi:g} is outside 18.5-24.9")]
    return []


def _score_glucose(glucose):
    if glucose is None:
        return []
    if glucose >= 250 or glucose < 54:
        return [(3, f"Glucose {glucose:g} mg/dL is far outside the simple range of 70-139")]
    if glucose >= 180 or glucose < 70:
        return [(2, f"Glucose {glucose:g} mg/dL is clearly outside 70-139")]
    if glucose >= 140:
        return [(1, f"Glucose {glucose:g} mg/dL is slightly raised (140-179)")]
    return []


def assess_risk(systolic=None, diastolic=None, heart_rate=None, temperature=None,
                oxygen=None, bmi=None, glucose=None):
    """Return {"level": "Low|Moderate|High|Not assessed", "reason": "..."}."""
    values = [systolic, diastolic, heart_rate, temperature, oxygen, bmi, glucose]
    if all(value is None for value in values):
        return {"level": NOT_ASSESSED, "reason": "No measurements were recorded, so no risk indicator was calculated."}

    findings = []
    findings += _score_blood_pressure(systolic, diastolic)
    findings += _score_heart_rate(heart_rate)
    findings += _score_temperature(temperature)
    findings += _score_oxygen(oxygen)
    findings += _score_bmi(bmi)
    findings += _score_glucose(glucose)

    highest = max([points for points, _ in findings], default=0)
    total = sum(points for points, _ in findings)

    if highest >= 3 or total >= 5:
        level = "High"
    elif highest >= 2 or total >= 2:
        level = "Moderate"
    else:
        level = "Low"

    if findings:
        reason = "; ".join(text for _, text in findings)
        reason += f". Score total: {total}."
    else:
        reason = "All recorded measurements are within the simple reference ranges used by this demo."
    return {"level": level, "reason": reason[:500]}
