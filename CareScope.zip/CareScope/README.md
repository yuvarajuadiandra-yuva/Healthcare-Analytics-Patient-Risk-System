# CareScope - Healthcare Management System

A simple Flask + MySQL web application for a B.Tech CSE (Data Science) project.
It has three roles (Admin, Doctor, Staff), patient and appointment management,
medical encounters with vital signs, and a transparent rule-based risk indicator.

> **Educational demonstration only.** The risk indicator is a simple rule-based
> example. It is not a medical diagnosis, not a clinical decision tool and has
> not been clinically validated.

## Technologies
Python 3.12, Flask, Flask-SQLAlchemy, Flask-Login, Flask-WTF, MySQL, HTML, CSS,
Bootstrap 5 and Chart.js. Bootstrap, Bootstrap Icons and Chart.js are loaded from
the jsDelivr CDN, so the browser needs an internet connection.
Supporting packages in `requirements.txt`: PyMySQL and cryptography (MySQL driver),
python-dotenv (reads `.env`) and email-validator (used by Flask-WTF for email fields).

## What you need installed first (Windows)
1. **Python 3.12** from https://www.python.org/downloads/ (tick "Add python.exe to PATH").
2. **MySQL Server 8.x** (MySQL Installer for Windows). Remember the `root` password you set.

## Installation (Windows, Command Prompt)

Open **Command Prompt** and go to the project folder (the folder that contains `run.py`):

```bat
cd path\to\CareScope

python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt

copy .env.example .env
```

### Edit `.env`
Open `.env` in Notepad and set:
* `SECRET_KEY` - generate one with:
  `python -c "import secrets; print(secrets.token_hex(32))"` and paste the result.
* `DB_PASSWORD` - your MySQL password.
* Leave `DB_NAME=carescope_dev` unless you changed the SQL file.

### Create the database and tables
The SQL file is safe to run more than once. It uses `CREATE ... IF NOT EXISTS`
and never drops or overwrites anything.

```bat
mysql -u root -p < database\schema.sql
```

If `mysql` is "not recognized", either run it with the full path, for example
`"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p < database\schema.sql`,
or open `database\schema.sql` in MySQL Workbench and run the whole script.

Optional check: `flask --app run init-db` creates any missing tables (it never changes
existing ones). It needs the database to exist already.

### Create the demo admin account
No accounts exist after setup, so create the first administrator:

```bat
flask --app run create-admin
```
Enter a full name, email, username and password (at least 8 characters with letters
and numbers). Choose your own password; none is shipped with the project.

### Run
```bat
python run.py
```
Open http://127.0.0.1:5000 and sign in with the admin account.

Next time you only need:
```bat
cd path\to\CareScope
venv\Scripts\activate
python run.py
```

## First-use workflow
1. Sign in as **Admin** -> **Departments** -> add departments.
2. **Doctors** -> add doctors (choose a department). **Staff** -> add staff accounts.
3. Sign in as **Staff** -> **Register Patient** (optionally assign a doctor) -> **Book Appointment**.
4. Sign in as **Doctor** -> **My Patients** -> **New encounter** (symptoms, vitals) to see the risk indicator.

## Roles and permissions (enforced on the server)
| Feature | Admin | Doctor | Staff |
|---|---|---|---|
| Dashboard | yes | yes | yes |
| Add / edit / deactivate doctors, staff, departments | yes | no | no |
| Register / edit patients | yes | no | yes |
| Deactivate / activate patients | yes | no | no |
| View patients | all | own assigned only | all (no medical records) |
| View medical records and encounters | no | own assigned patients | no |
| Add / edit encounters, record vitals | no | yes (own encounters) | no |
| Book appointments | no | no | yes |
| Update appointment status | no | no | yes (Scheduled/Confirmed -> Confirmed/Completed/Cancelled/No-Show) |
| View appointments | all | own | all |
| Reports | yes | no | no |

## Risk indicator rules (see `app/services/risk.py`)
Each recorded measurement scores 0-3 points (blood pressure, heart rate, temperature,
oxygen saturation, BMI, glucose). **High** = any measurement scores 3 or total is 5+;
**Moderate** = any measurement scores 2 or total is 2+; otherwise **Low**. The reasons
are shown next to the category. Dashboards use each active patient's most recent encounter.

## Design notes
* Patient age is calculated from the date of birth when displayed, so it is never stale.
* Patient codes look like `CS00001` and are generated when a patient is registered.
* Passwords are hashed with Werkzeug; forms use CSRF protection; logout is a POST request.
* Duplicate bookings are blocked: same doctor+time, same patient+time, or same patient+doctor+day
  (cancelled appointments do not count).
* An audit log table records sign-ins and changes; the last 15 entries appear under Reports.

## Project structure
```
CareScope/
  app/            __init__.py, extensions.py, models.py, routes.py
    services/     risk.py (risk rules), audit.py (audit log helper)
    templates/    HTML pages (base.html, auth/, admin/, doctor/, staff/, patients/, appointments/, encounters/, errors/)
    static/css/   style.css
  database/schema.sql
  config.py  run.py  requirements.txt  .env.example  README.md
```

## Troubleshooting
* `RuntimeError: SECRET_KEY is not set` -> create `.env` from `.env.example` and set `SECRET_KEY`.
* `Can't connect to MySQL server` / 500 page -> make sure the MySQL service is running and
  `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` in `.env` are correct.
* `Unknown database 'carescope_dev'` or `Table ... doesn't exist` -> run the schema command above.
* `'flask' is not recognized` -> activate the virtual environment: `venv\Scripts\activate`.
