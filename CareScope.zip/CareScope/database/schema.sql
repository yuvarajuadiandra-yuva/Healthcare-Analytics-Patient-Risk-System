-- CareScope database schema (MySQL 8.x)
-- SAFE TO RE-RUN: it only creates things that do not exist yet.
-- It never drops a database, never drops a table and never deletes data.
--
-- Run from the project folder:  mysql -u root -p < database\schema.sql

CREATE DATABASE IF NOT EXISTS carescope_dev
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE carescope_dev;

CREATE TABLE IF NOT EXISTS departments (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    description VARCHAR(255) NULL,
    is_active   TINYINT(1)   NOT NULL DEFAULT 1,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_departments_name (name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
    id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name      VARCHAR(120) NOT NULL,
    email          VARCHAR(120) NOT NULL,
    username       VARCHAR(50)  NOT NULL,
    password_hash  VARCHAR(255) NOT NULL,
    role           ENUM('admin','doctor','staff') NOT NULL,
    phone          VARCHAR(20)  NULL,
    department_id  INT UNSIGNED NULL,
    specialization VARCHAR(100) NULL,
    designation    VARCHAR(100) NULL,
    is_active      TINYINT(1)   NOT NULL DEFAULT 1,
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_username (username),
    KEY ix_users_role (role),
    CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS patients (
    id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_code       VARCHAR(20)  NOT NULL,
    full_name          VARCHAR(120) NOT NULL,
    date_of_birth      DATE         NOT NULL,
    gender             ENUM('Male','Female','Other') NOT NULL,
    phone              VARCHAR(20)  NOT NULL,
    email              VARCHAR(120) NULL,
    address            VARCHAR(255) NULL,
    blood_group        VARCHAR(5)   NULL,
    assigned_doctor_id INT UNSIGNED NULL,
    registered_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status             ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    created_by         INT UNSIGNED NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_patients_code (patient_code),
    KEY ix_patients_name (full_name),
    KEY ix_patients_doctor (assigned_doctor_id),
    CONSTRAINT fk_patients_doctor  FOREIGN KEY (assigned_doctor_id) REFERENCES users (id),
    CONSTRAINT fk_patients_creator FOREIGN KEY (created_by)         REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS appointments (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id       INT UNSIGNED NOT NULL,
    doctor_id        INT UNSIGNED NOT NULL,
    appointment_date DATE         NOT NULL,
    appointment_time TIME         NOT NULL,
    reason           VARCHAR(255) NOT NULL,
    status           ENUM('Scheduled','Confirmed','Completed','Cancelled','No-Show') NOT NULL DEFAULT 'Scheduled',
    created_by       INT UNSIGNED NULL,
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY ix_appointments_slot (doctor_id, appointment_date, appointment_time),
    KEY ix_appointments_patient (patient_id),
    CONSTRAINT fk_appointments_patient FOREIGN KEY (patient_id) REFERENCES patients (id),
    CONSTRAINT fk_appointments_doctor  FOREIGN KEY (doctor_id)  REFERENCES users (id),
    CONSTRAINT fk_appointments_creator FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS encounters (
    id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    patient_id        INT UNSIGNED NOT NULL,
    doctor_id         INT UNSIGNED NOT NULL,
    encounter_date    DATE         NOT NULL,
    symptoms          TEXT         NOT NULL,
    diagnosis         TEXT         NULL,
    systolic_bp       INT          NULL,
    diastolic_bp      INT          NULL,
    heart_rate        INT          NULL,
    temperature       DECIMAL(4,1) NULL,
    oxygen_saturation INT          NULL,
    bmi               DECIMAL(4,1) NULL,
    glucose           DECIMAL(5,1) NULL,
    treatment_notes   TEXT         NULL,
    follow_up_date    DATE         NULL,
    risk_level        VARCHAR(20)  NOT NULL DEFAULT 'Not assessed',
    risk_reason       VARCHAR(500) NULL,
    created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY ix_encounters_patient (patient_id),
    KEY ix_encounters_doctor (doctor_id),
    CONSTRAINT fk_encounters_patient FOREIGN KEY (patient_id) REFERENCES patients (id),
    CONSTRAINT fk_encounters_doctor  FOREIGN KEY (doctor_id)  REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    INT UNSIGNED NULL,
    action     VARCHAR(60)  NOT NULL,
    details    VARCHAR(255) NULL,
    ip_address VARCHAR(45)  NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY ix_audit_created (created_at),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB;
